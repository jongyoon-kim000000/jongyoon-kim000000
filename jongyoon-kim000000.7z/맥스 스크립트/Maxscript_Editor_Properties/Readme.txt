ScreenShot를 참고하여

파일들의 내용을 복사붙여넣기 하시거나
혹은 직접 경로를 찾아서 파일대체하시면 됩니다


경로 
C:\Users\<사용자이름>\AppData\Local\Autodesk\3dsMax\2020 - 64bit\ENU
- MXS_EditorUser.properties

C:\Program Files\Autodesk\3ds Max 2020
- MAXScript.properties
- MXS_Editor.properties



사용법
- Ctrl+Space = Maxscript Method 자동완성
- Ctrl+Enter = 사용자 선언 변수, 함수 자동완성