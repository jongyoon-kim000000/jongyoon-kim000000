JJTools2013

The scripts contained in this file were written for 3ds Max 2013.  They should work fine in R5, R6, R7 and R8 but they have not been rigourously tested.  Please download R4, R5, R6, R7, R8, R9, 2008, 2009, 2010, 2011 and 2012 scripts from www.jimjagger.com

Installation
Place all .mcr files in 3ds Max 2013\ui\macroscripts
Place all .bmp files in 3ds Max 2013\ui\icons
Place JJTools2013_Functions.ms in 3ds Max 2013\stdplugs\stdscripts
Place JJTools2013_SelectOpposite.ms in 3ds Max 2013\Scripts\JJTools9
Place JJTools2013_SelectReloadfile.ms in 3ds Max 2013\Scripts\startup

Restart Max
JJTools2013 can be found in the Customise UI window under the category JJTools 2013

Suggestions for improvements are welcomed
www.jimjagger.com
jimjagger@gmail.com

Cheers,
Jim